with open("input.txt", "r") as filestream:
    with open("output.txt", "w") as filestreamtwo:
        for line in filestream:
            currentline = line.strip().split(",")



           # if currentline[1] == "Dirty /n":


           # total = str((currentline[0]) + (currentline[1]) )


            if currentline[0]=="A" and currentline[1]!="Dirty":
                filestreamtwo.write("Right\n")
            if currentline[0]=="B" and currentline[1]!="Dirty":
                filestreamtwo.write("Left\n")
            if currentline[1] == "Dirty" and (currentline[0]=="A" or currentline[0]=="B"):
                filestreamtwo.write("Suck\n")




            #filestreamtwo.write(line)